"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Kartike Sachdeva
ID:      169049497
Email:   sach9497@mylaurier.ca
__updated__ = "2023-11-10"
-------------------------------------------------------
"""
# Imports
from functions import many_search
# Constants

user_input = input("Enter a list of values: ")
input_list = user_input.split(',')
values = [float(item) for item in input_list]

user_input = input("Enter a list of values: ")
input_list = user_input.split(',')
value = [float(item) for item in input_list]

indexes = many_search(values, value)
print(indexes)

"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Kartike Sachdeva
ID:      169049497
Email:   sach9497@mylaurier.ca
__updated__ = "2023-11-10"
-------------------------------------------------------
"""
# Imports
from functions import get_digit_name
# Constants

n = int(input("Enter a digit (0 to 9): "))

name = get_digit_name(n)
print(name)

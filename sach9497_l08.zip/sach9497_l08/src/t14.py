"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Kartike Sachdeva
ID:      169049497
Email:   sach9497@mylaurier.ca
__updated__ = "2023-11-10"
-------------------------------------------------------
"""
# Imports
from functions import intersection
# Constants

source1 = [float(x) for x in input(
    "Enter the first list of values separated by spaces: ").split()]
source2 = [float(x) for x in input(
    "Enter the second list of values separated by spaces: ").split()]

result = intersection(source1, source2)
print(f"Intersection of lists: {result}")

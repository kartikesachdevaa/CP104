"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Kartike Sachdeva
ID:      169049497
Email:   sach9497@mylaurier.ca
__updated__ = "2023-10-25"
-------------------------------------------------------
"""
# Imports
from functions import sum_all

# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


start = int(input("Enter the start value: "))
finish = int(input("Enter the finish value: "))
increment = int(input("Enter the increment value: "))

total = sum_all(start, finish, increment)
print(total)

"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Kartike Sachdeva
ID:      169049497
Email:   sach9497@mylaurier.ca
__updated__ = "2023-10-26"
-------------------------------------------------------
"""
# Imports
from functions import draw_hollow_triangle
# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


width = int(input("Enter the width: "))
char = input("Enter the character: ")
result = draw_hollow_triangle(width, char)

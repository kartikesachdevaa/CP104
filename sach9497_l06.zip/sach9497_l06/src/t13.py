"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Kartike Sachdeva
ID:      169049497
Email:   sach9497@mylaurier.ca
__updated__ = "2023-10-26"
-------------------------------------------------------
"""
# Imports
from functions import lumber
# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


b_min = int(input("Enter the minimum base value: "))
b_max = int(input("Enter the maximum base value: "))
b_inc = int(input("Enter the increment in base value: "))
h_min = int(input("Enter the minimum height value: "))
h_max = int(input("Enter the maximum height value: "))
h_inc = int(input("Enter the increment in height value: "))

lumber(b_min, b_max, b_inc, h_min, h_max, h_inc)

"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Kartike Sachdeva
ID:      169049497
Email:   sach9497@mylaurier.ca
__updated__ = "2023-11-03"
-------------------------------------------------------
"""
# Imports
from functions import budget
# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


available = float(input("Enter the money currently available: $"))
expenses, balance, status = budget(available)
print(f"Total monthly expenses: ${expenses:.2f}")
print(f"Remaining balance: ${balance:.2f}")
print(f"Budget status: {status}")

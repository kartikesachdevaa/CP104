"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Kartike Sachdeva
ID:      169049497
Email:   sach9497@mylaurier.ca
__updated__ = "2023-11-03"
-------------------------------------------------------
"""
# Imports
from random import randint
# Constants


def hi_lo_game(high):
    """
    -------------------------------------------------------
    Plays a random higher-lower guessing game.
    Use: count = hi_lo_game(high)
    -------------------------------------------------------
    Parameters:
        high - maximum random value (int > 1)
    Returns:
        count - the number of guesses the user made (int)
    -------------------------------------------------------
    """

    number = randint(1, high)
    count = 0

    while True:
        guess = int(input("Guess: "))
        count += 1

        if guess < number:
            print("Too low, try again.")
        elif guess > number:
            print("Too high, try again.")
        else:
            print("Congratulations - good guess!")
            print(f"You made {count} guesses.")
            return count


def power_of_two(target):
    """
    -------------------------------------------------------
    Determines the nearest power of 2 greater than or equal to
    a given target.
    Use: power = power_of_two(target)
    -------------------------------------------------------
    Parameters:
        target - value to find nearest power of 2 (int >= 0)
    Returns:
        power - first power of 2 >= target (int)
    -------------------------------------------------------
    """
    if target <= 0:
        output = 1
    power = 1
    while power < target:
        power *= 2
    output = power

    return output


def sum_squares(target):
    """
    -------------------------------------------------------
    Determines the sum of squares closest to, and greater than or
    equal to, a target value.
    Use: final = sum_squares(target)
    -------------------------------------------------------
    Parameters:
        target - target value (int >= 0)
    Returns:
        final - the final sum of squares >= target (int)
    -------------------------------------------------------
    """

    if target < 0:
        result = None
    else:
        C_num = 1
        C_sum = 1

        while C_sum < target:
            C_num += 1
            C_sum += C_num ** 2

        result = 1 if target == 0 else C_sum

    return result


def budget(available):
    """
    -------------------------------------------------------
    Asks a user for a series of expenses in a month. Calculate the
    total expenses and determines whether the user is in "Surplus",
    "Deficit", or "Balanced" status.
    Use: expenses, balance, status = budget(available)
    -------------------------------------------------------
    Parameters:
        available - money currently available (float >= 0)
    Returns:
        expenses - total monthly expenses (float)
        balance - remaining balance (float)
        status - One of (str):
            "Surplus" if user budget is in surplus
            "Deficit" if user budget is in deficit
            "Balanced" if user budget is balanced
    ------------------------------------------------------
    """

    expenses = 0.0
    while True:
        expense = float(input("Enter an expense (0 to quit): $"))
        if expense == 0:
            break
        expenses += expense

    balance = available - expenses

    if balance > 0:
        status = "Surplus"
    elif balance < 0:
        status = "Deficit"
    else:
        status = "Balanced"

    return expenses, balance, status


def employee_payroll():
    """
    -------------------------------------------------------
    Calculates and returns the weekly employee payroll for all employees
    in an organization. For each employee, ask the user for the employee ID
    number, the hourly wage rate, and the number of hours worked during a week.
    An employee number of zero indicates the end of user input.
    Each employee is paid 1.5 times their regular hourly rate for all hours
    over 40. A tax amount of 3.625 percent of gross salary is deducted.
    Use: total, average = employee_payroll()
    -------------------------------------------------------
    Returns:
        total - total net employee wages (i.e. after taxes) (float)
        average - average employee net wages (float)
    ------------------------------------------------------
    """

    TAX_RATE = 3.625
    OVERTIME_RATE = 1.5
    REGULAR_HOURS = 40

    total_net_payment = 0
    num_employees = 0

    while True:
        employee_id = int(input("Employee ID: "))
        if employee_id == 0:
            break

        hourly_wage_rate = float(input("Hourly wage rate: $"))
        hours_worked = float(input("Hours worked: "))

        gross_payment = hourly_wage_rate * \
            (hours_worked if hours_worked <= REGULAR_HOURS else REGULAR_HOURS +
             (hours_worked - REGULAR_HOURS) * OVERTIME_RATE)
        tax_amount = (gross_payment * TAX_RATE) / 100
        net_payment = gross_payment - tax_amount

        total_net_payment += net_payment
        num_employees += 1

        print(f"Net payment for employee {employee_id}: ${net_payment:.2f}")

    if num_employees == 0:
        average_net_payment = 0
    else:
        average_net_payment = total_net_payment / num_employees

    return total_net_payment, average_net_payment

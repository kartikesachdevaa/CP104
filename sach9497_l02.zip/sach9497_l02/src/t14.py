"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Kartike Sachdeva
ID:      169049497
Email:   sach9497@mylaurier.ca
__updated__ = "2023-09-13"
-------------------------------------------------------
"""
# Imports

# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


# serving size of six portions
MILK = 4
BUTTER = 8
FLOUR = 0.5
SALT = 2

# serving size for one portion
milk_for_1 = MILK/6
butter_for_1 = BUTTER/6
flour_for_one = FLOUR/6
salt_for_one = SALT/6

serving_size = int(input("Enter servings of Mac & Cheese: "))

required_milk_portion = milk_for_1 * serving_size
required_butter_portion = butter_for_1 * serving_size
required_flour_portion = flour_for_one * serving_size
required_salt_portion = salt_for_one * serving_size


print(f"{serving_size} servings of Mac and Cheese requires:")
print(f"Milk (cups): {required_milk_portion:.2f}")
print(f"Butter (tablespoons): {required_butter_portion:.2f}")
print(f"Flour (cups): {required_flour_portion:.2f}")
print(f"Salt (tablespoons: {required_salt_portion:.2f}")

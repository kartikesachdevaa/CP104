"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Kartike Sachdeva
ID:      169049497
Email:   sach9497@mylaurier.ca
__updated__ = "2023-09-12"
-------------------------------------------------------
"""
# Imports

# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


hourly_rate = float(input("please enter your hourly rate of pay: $"))
hours_worked = float(
    input("please enter the number of hours you worked last week: $"))


total_pay = hourly_rate*hours_worked
print("Total pay for the week: $", total_pay)

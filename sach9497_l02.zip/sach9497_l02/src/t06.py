"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Kartike Sachdeva
ID:      169049497
Email:   sach9497@mylaurier.ca
__updated__ = "2023-09-13"
-------------------------------------------------------
"""
# Imports

# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


principal = float(input("Mortgage principal ($): "))
years = int(input("number of years: "))
interest_rate = float(input("yearly intrest rate: "))

monthly_interest_rate = (interest_rate / 100) / 12
total_payments = years * 12

monthly_payment = principal * (monthly_interest_rate * (1 + monthly_interest_rate)
                               ** total_payments) / ((1 + monthly_interest_rate) ** total_payments - 1)

print("The monthly payments are: $", monthly_payment)

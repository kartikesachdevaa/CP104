"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Kartike Sachdeva
ID:      169049497
Email:   sach9497@mylaurier.ca
__updated__ = "2023-09-15"
-------------------------------------------------------
"""
# Imports

# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


SECONDS_PER_MINUTE = 60

seconds = int(input("please enter the number of seconds: "))
minutes, seconds = divmod(seconds, SECONDS_PER_MINUTE)
hours, minutes = divmod(minutes, SECONDS_PER_MINUTE)
days, hours = divmod(hours, 24)
print(f"Days: {days}, Hours: {hours}, Minutes: {minutes}, Seconds: {seconds}")

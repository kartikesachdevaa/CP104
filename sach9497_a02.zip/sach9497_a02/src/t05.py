"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Kartike Sachdeva
ID:      169049497
Email:   sach9497@mylaurier.ca
__updated__ = "2023-10-07"
-------------------------------------------------------
"""
# Imports

# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


foundation_length = float(input("Foundation length (m): "))
foundation_width = float(input("Foundation width (m): "))
foundation_height = float(input("Foundation height (m): "))
wall_height = float(input("Wall height (m): "))
cost_concrete_per_m3 = float(input("Cost of concrete ($/m^3): "))
cost_bricks_per_m2 = float(input("Cost of bricks ($/m^2): "))
foundation_volume = foundation_length * foundation_width * foundation_height
wall_area = 2 * (foundation_length * wall_height +
                 foundation_width * wall_height)
concrete_needed = foundation_volume
concrete_cost = concrete_needed * cost_concrete_per_m3
bricks_needed = wall_area
bricks_cost = bricks_needed * cost_bricks_per_m2
total_cost = concrete_cost + bricks_cost
print(f"Concrete needed for foundation (m^3): {concrete_needed:,.2f}")
print(f"Cost of concrete: ${concrete_cost:,.2f}")
print(f"Bricks needed for walls (m^2): {bricks_needed:,.2f}")
print(f"Cost of bricks: ${bricks_cost:,.2f}")
print(f"Total cost: ${total_cost:,.2f}")

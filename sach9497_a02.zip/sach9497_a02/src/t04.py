"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Kartike Sachdeva
ID:      169049497
Email:   sach9497@mylaurier.ca
__updated__ = "2023-10-07"
-------------------------------------------------------
"""
# Imports

# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


number_flyers = int(input("Enter number of flyers: "))
number_people = int(input("Enter number of people for delivery: "))

flyers_per_person = number_flyers//number_people
flyers_left = number_flyers % number_people
print(f"Flyers per delivery person: {flyers_per_person}")
print(f"Flyers left over: {flyers_left}")

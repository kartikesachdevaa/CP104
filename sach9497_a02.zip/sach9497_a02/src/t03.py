"""
   -------------------------------------------------------
   [program description]
   -------------------------------------------------------
   Author:  Kartike Sachdeva
   ID:      169049497
   Email:   sach9497@mylaurier.ca
   __updated__ = "2023-10-07"
   -------------------------------------------------------
   """
# Imports

# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


enter_date = int(input("please enter the date in YYYYMMDD: "))
month = (enter_date // 100) % 100
day = enter_date % 100
year = enter_date // 10000

print(f"Formatted date is: {year}/{month:02d}/{day:02d}")

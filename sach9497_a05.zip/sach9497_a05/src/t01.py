"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Kartike Sachdeva
ID:      169049497
Email:   sach9497@mylaurier.ca
__updated__ = "2023-11-04"
-------------------------------------------------------
"""
# Imports
from functions import calc_factorial
# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


user_input = int(
    input("Enter a Number: "))
result = calc_factorial(user_input)

if result is not None:
    print(f"{user_input} -> {result}")
else:
    print("Invalid input. Please enter a non-negative integer.")

"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Kartike Sachdeva
ID:      169049497
Email:   sach9497@mylaurier.ca
__updated__ = "2023-12-02"
-------------------------------------------------------
"""
# Imports
from functions import file_statistics
# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


file_path = "addresses.txt"

with open(file_path, "r", encoding="utf-8") as file_handle:
    ucount, lcount, dcount, wcount, rcount = file_statistics(file_handle)

    print(f"file_statistics(file_handle) -> {ucount}, {lcount}, {dcount}, {wcount}, {rcount}")

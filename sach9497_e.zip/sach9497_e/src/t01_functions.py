"""
-------------------------------------------------------
Exam Task 1 Function Definitions
-------------------------------------------------------
Author: Kartike Sachdeva
ID:     169049497
Email:  sach9497@mylaurier.ca
__updated__ = "2023-12-14"
-------------------------------------------------------
"""


def even_avg(values):
    """
    -------------------------------------------------------
    Returns the average (integer, rounded down) of all even numbers
    in values. If values has no even numbers, the average is 0.
    Use: ea = even_avg(values)
    -------------------------------------------------------
    Parameters:
        values - a list of values (list of int)
    Returns‌​‌​​​​‌​​‌‌​‌‌‌‌‌​‌‌​​‌‌​​‌:
        ea - the average of the even numbers in values (int)
    -------------------------------------------------------
    """
    even_numbers = [num for num in values if num % 2 == 0]

    if even_numbers:
        ea = sum(even_numbers) // len(even_numbers)
    else:
        ea = 0

    return ea

    values = [1, 2, 3, 4, 5, 6, 7, 8, 9]
    result = even_avg(values)
    print(f"The average of even numbers is: {result}")

    return None

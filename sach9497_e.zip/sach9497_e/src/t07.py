"""
-------------------------------------------------------
Testing for Task 7: line_lengths
-------------------------------------------------------
Author: Kartike Sachdeva
ID:     169049497
Email:  sach9497@mylaurier.ca
__updated__ = "2023-12-14"
-------------------------------------------------------
"""
from t07_functions import line_lengths


with open("source.txt", 'r') as file_in, open("short_lines.txt", 'w') as file_short, open("long_lines.txt", 'w') as file_long:
    n_value = 16
    short_count, long_count = line_lengths(file_in, file_short, file_long, n_value)

print(f"Number of lines with length < {n_value}: {short_count}")
print(f"Number of lines with length >= {n_value}: {long_count}")

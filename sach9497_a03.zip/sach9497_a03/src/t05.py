"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Kartike Sachdeva
ID:      169049497
Email:   sach9497@mylaurier.ca
__updated__ = "2023-10-21"
-------------------------------------------------------
"""
# Imports
from functions import falling_distance
# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


falling_time = int(input("Enter the falling time: "))
distance = falling_distance(falling_time)
print(distance)

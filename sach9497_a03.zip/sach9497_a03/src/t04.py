"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Kartike Sachdeva
ID:      169049497
Email:   sach9497@mylaurier.ca
__updated__ = "2023-10-21"
-------------------------------------------------------
"""
# Imports
from functions import multiply_fractions
# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


num1 = int(input("Enter number 1: "))
den1 = int(input("Enter denominator 1: "))
num2 = int(input("Enter number 2: "))
den2 = int(input("Enter denominator 2: "))

num, den, product = multiply_fractions(num1, den1, num2, den2)
print(num, den, product)

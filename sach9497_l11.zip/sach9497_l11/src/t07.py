"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Kartike Sachdeva
ID:      169049497
Email:   sach9497@mylaurier.ca
__updated__ = "2023-11-30"
-------------------------------------------------------
"""
# Imports
from functions import find_position
# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use:
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


print("Enter the matrix, row by row, each element separated by a space:")
matrix = []

while True:
    row_input = input("Enter row (or type 'done' to finish): ")
    if row_input.lower() == 'done':
        break
    row = list(map(int, row_input.split()))
    matrix.append(row)

s_loc, l_loc = find_position(matrix)

print("\nfind_position({0}) ->".format(matrix))
print("({0}, {1})".format(s_loc, l_loc))

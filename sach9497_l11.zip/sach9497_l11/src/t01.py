"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Kartike Sachdeva
ID:      169049497
Email:   sach9497@mylaurier.ca
__updated__ = "2023-11-29"
-------------------------------------------------------
"""
# Imports
from functions import generate_matrix_num
# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


rows = int(input("Enter the number of rows: "))
cols = int(input("Enter the number of columns: "))
low = float(input("Enter the low value of range: "))
high = float(input("Enter the high value of range: "))
value_type = input("Enter the type of values ('float' or 'int'): ")

matrix = generate_matrix_num(rows, cols, low, high, value_type)
print(matrix)

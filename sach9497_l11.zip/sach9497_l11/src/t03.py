"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Kartike Sachdeva
ID:      169049497
Email:   sach9497@mylaurier.ca
__updated__ = "2023-12-01"
-------------------------------------------------------
"""
# Imports
from functions import print_matrix_num
# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


print("Enter the matrix, row by row, each element separated by a space:")
matrix = []

while True:
    row_input = input("Enter row (or type 'done' to finish): ")
    if row_input.lower() == 'done':
        break
    row = list(map(float, row_input.split()))
    matrix.append(row)

print("\nOriginal Matrix:")
print_matrix_num(matrix, 'float')

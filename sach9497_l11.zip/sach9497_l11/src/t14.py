"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Kartike Sachdeva
ID:      169049497
Email:   sach9497@mylaurier.ca
__updated__ = "2023-11-30"
-------------------------------------------------------
"""
# Imports
from functions import matrix_transpose
# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


print("Enter the matrix, row by row, each element separated by a space:")
matrix = []

while True:
    row_input = input("Enter row (or type 'done' to finish): ")
    if row_input.lower() == 'done':
        break
    row = list(map(int, row_input.split()))
    matrix.append(row)

print("\nOriginal Matrix:")
for row in matrix:
    print("\t".join(map(str, row)))

transposed_matrix = matrix_transpose(matrix)

print("\nTransposed Matrix:")
for row in transposed_matrix:
    print("\t".join(map(str, row)))

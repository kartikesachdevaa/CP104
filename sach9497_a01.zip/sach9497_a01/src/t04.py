"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Kartike Sachdeva
ID:      169049497
Email:   sach9497@mylaurier.ca
__updated__ = "2023-09-15"
-------------------------------------------------------
"""
# Imports

# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


cost_1_dosa = float(input("please enter the cose of one dosa: "))

no_of_dosas = int(input("please enter the number of dosas you want: "))

total_price = cost_1_dosa * no_of_dosas

print(f"Total cost of {no_of_dosas} dosas is: ${total_price}")

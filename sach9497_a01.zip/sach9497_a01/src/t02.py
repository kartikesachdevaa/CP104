"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Kartike Sachdeva
ID:      169049497
Email:   sach9497@mylaurier.ca
__updated__ = "2023-09-15"
-------------------------------------------------------
"""
# Imports

# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


age = input("What is your age: ")
band = input("What is your favourite band: ")

print(f"I am {age} years old and {band}is my favourite band.")

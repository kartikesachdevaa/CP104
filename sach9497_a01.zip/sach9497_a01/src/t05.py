"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Kartike Sachdeva
ID:      169049497
Email:   sach9497@mylaurier.ca
__updated__ = "2023-09-15"
-------------------------------------------------------
"""
# Imports

# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


principal = float(input("please enter the principal amount ($): "))
interest = float(input("please enter the interest (%): "))
years = int(input("Number of years: "))
no_of_comp_times = int(
    input("please enter number of times interest compounded per year: "))


amount = principal*(1+interest/(no_of_comp_times*100)
                    )**(no_of_comp_times*years)

print(f"The balance is: {amount}")

"""
-------------------------------------------------------
Midterm A Task 4 Testing
-------------------------------------------------------
Author: Kartike Sachdeva
ID:     169049497
Email:  sach9497@mylaurier.ca
__updated__ = "2023-11-01"
-------------------------------------------------------
"""
# Imports
from t04_functions import result
# your code here
response = input("Enter a response: ")
classification = result(response)
print(f"result({response}) -> {classification}")

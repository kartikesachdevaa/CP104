"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Kartike Sachdeva
ID:      169049497
Email:   sach9497@mylaurier.ca
__updated__ = "2023-11-11"
-------------------------------------------------------
"""
# Imports

# Constants


def total_wins():
    """
    -------------------------------------------------------
    Takes no parameters and prompts the user to enter a series
    of strings representing the output of a game until an empty
    string is entered. Counts and returns the occurrences of
    'purple' and 'gold' in the input.

    Use: result = total_wins()
    -------------------------------------------------------
    Returns:
        result - A tuple containing the count of 'purple' and
                 'gold' occurrences.
    """
    purple_count = 0
    gold_count = 0

    while True:
        user_input = input("Enter the winning team: ").lower()

        if user_input == '':
            break

        if user_input == 'purple':
            purple_count += 1
        elif user_input == 'gold':
            gold_count += 1

    return purple_count, gold_count


def detect_prime(number):
    """
    -------------------------------------------------------
    Determines if number is a prime number.
    Use: prime = detect_prime(number)
    -------------------------------------------------------
    Parameters:
        number - an integer (int > 1)
    Returns:
        prime - True if number is prime, False otherwise (bool)
    ------------------------------------------------------
    """
    if number <= 1:
        output = False

    divisor = 2

    while divisor * divisor <= number:
        if number % divisor == 0:
            output = False
        divisor += 1

    output = True

    return output


def interest_table(principal_amount, interest_rate, payment):
    """
    -------------------------------------------------------
    Prints a table of monthly interest and payments on a loan.
    Use: interest_table(principal_amount, interest_rate, payment)
    -------------------------------------------------------
    Parameters:
        principal_amount - original value of a loan (float > 0)
        interest_rate - yearly interest interest_rate as a % (float >= 0)
        payment - the monthly payment (float > 0)
    Returns:
        None
    ------------------------------------------------------
    """

    if principal_amount <= 0 or interest_rate < 0 or payment <= 0:
        print("Error: Invalid input. Please ensure principal_amount is greater than 0, "
              "interest_rate is greater than or equal to 0, and payment is greater than 0.")
        return

    monthly_interest_rate = interest_rate / 100 / 12
    remaining_balance = principal_amount
    month = 1

    print(f"Principal:   ${principal_amount:.2f}")
    print(f"Interest rate : {interest_rate:.2f}%")
    print(f"Monthly payment: ${payment:.2f}")
    print("----------------------------------")
    print(f"{'Month':<6}{'Interest':<10}{'Payment':<10}{'Balance':<10}")
    print("----------------------------------")

    while remaining_balance > 0:
        monthly_interest = remaining_balance * monthly_interest_rate
        remaining_balance = max(0, remaining_balance -
                                (payment - monthly_interest))

        print(f"{month:<6}{monthly_interest:.2f}{payment:.2f}{remaining_balance:.2f}")
        month += 1


def count_of_digits(number):
    """
    -------------------------------------------------------
    Counts the number of digits in an integer.
    Use: digits = count_of_digits(number)
    -------------------------------------------------------
    Parameters:
        number - an integer (int)
    Returns:
        digits - the number of digits in number (int)
    ------------------------------------------------------
    """

    if number < 0:
        number = abs(number)  # Make the number positive for counting digits

    digits = 0

    while number > 0:
        number //= 10  # Integer division by 10 removes the last digit
        digits += 1

    return digits


def factor_summation(number):
    """
    -------------------------------------------------------
    Determines the sum of factors of an integer not including
    the integer itself. An integer's factors are the whole numbers
    that the integer can be evenly divided by.
    Use: total = factor_summation(number)
    -------------------------------------------------------
    Parameters:
        number - a positive integer (int >= 1)
    Returns:
        total - the total of number's factors (int)
    ------------------------------------------------------
    """
    total = 0
    factor_candidate = 1

    while factor_candidate <= number // 2:
        if number % factor_candidate == 0:
            total += factor_candidate

        factor_candidate += 1

    return total

"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Kartike Sachdeva
ID:      169049497
Email:   sach9497@mylaurier.ca
__updated__ = "2023-11-11"
-------------------------------------------------------
"""
# Imports
from functions import interest_table
# Constants


principal_amount_input = float(input("Enter the principal amount: "))
interest_rate_input = float(input("Enter the yearly interest rate: "))
payment_input = float(input("Enter the monthly payment: "))

interest_table(principal_amount_input, interest_rate_input, payment_input)

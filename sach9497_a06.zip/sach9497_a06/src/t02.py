"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Kartike Sachdeva
ID:      169049497
Email:   sach9497@mylaurier.ca
__updated__ = "2023-11-11"
-------------------------------------------------------
"""
# Imports
from functions import detect_prime
# Constants


number_to_test = int(input("Enter a number: "))
result = detect_prime(number_to_test)

if result:
    print(f"{number_to_test} -> True.")
else:
    print(f"{number_to_test} -> False.")

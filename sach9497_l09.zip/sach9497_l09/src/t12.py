"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Kartike Sachdeva
ID:      169049497
Email:   sach9497@mylaurier.ca
__updated__ = "2023-11-17"
-------------------------------------------------------
"""
# Imports


from functions import comma_period_replace


input_string = input("Enter a words with commas: ")

result = comma_period_replace(input_string)
print(result)

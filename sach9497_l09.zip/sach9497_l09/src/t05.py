"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Kartike Sachdeva
ID:      169049497
Email:   sach9497@mylaurier.ca
__updated__ = "2023-11-17"
-------------------------------------------------------
"""
# Imports

from functions import password_strength

user_password = input("Enter a password: ")
password_strength(user_password)

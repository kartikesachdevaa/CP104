"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Kartike Sachdeva
ID:      169049497
Email:   sach9497@mylaurier.ca
__updated__ = "2023-11-17"
-------------------------------------------------------
"""
# Imports

from functions import validate_code

product_code = input("Enter a product code: ")


result = validate_code(product_code)

print(result)

"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Kartike Sachdeva
ID:      169049497
Email:   sach9497@mylaurier.ca
__updated__ = "2023-10-06"
-------------------------------------------------------
"""
# Imports
from functions import pythag
# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


s1 = float(input("Enter the length of side 1 of the right triangle: "))
s2 = float(input("Enter the length of side 2 of the right triangle: "))

radius, diam, circ, area = pythag(s1, s2)

print(f"{radius}, {diam}, {circ}, {area}")

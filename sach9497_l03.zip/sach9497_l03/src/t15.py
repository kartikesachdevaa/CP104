"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Kartike Sachdeva
ID:      169049497
Email:   sach9497@mylaurier.ca
__updated__ = "2023-09-29"
-------------------------------------------------------
"""
# Imports

# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


integer = 654321
decimal = 654.32
phrase = "Hello World"


print("Printing integer as an integer:")
print(f"Integer: {integer:d}")


print("\nPrinting integer as a floating point (real number) value:")
print(f"Integer as float: {integer:.2f}")


print("\nPrinting integer as a string:")
print(f"Integer as string: {str(integer)}")


print("\nPrinting decimal as an integer:")
print(f"Decimal as integer: {int(decimal)}")


print("\nPrinting decimal as a floating point (real number) value:")
print(f"Decimal as float: {decimal:.2f}")


print("\nPrinting decimal as a string:")
print(f"Decimal as string: {str(decimal)}")


# print("\nPrinting phrase as a floating point (real number) value:")
# print(f"Phrase as float: {float(phrase)}")

# print("\nPrinting phrase as an integer:")
# print(f"Phrase as integer: {int(phrase)}")


print("\nPrinting phrase as a string:")
print(f"Phrase as string: {phrase}")

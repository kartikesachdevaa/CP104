"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Kartike Sachdeva
ID:      169049497
Email:   sach9497@mylaurier.ca
__updated__ = "2023-11-23"
-------------------------------------------------------
"""
# Imports
from functions import count_frequency_word
# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


file_path = 'words.txt'
word_to_search = input("Enter the word to search for: ")

with open(file_path, 'r') as file_handle:
    count = count_frequency_word(file_handle, word_to_search)

print(f"'{word_to_search}' appears {count} time(s)")

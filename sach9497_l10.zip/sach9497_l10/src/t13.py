"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Kartike Sachdeva
ID:      169049497
Email:   sach9497@mylaurier.ca
__updated__ = "2023-11-23"
-------------------------------------------------------
"""
# Imports
from functions import file_copy
# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


source_file_path = 'words.txt'
target_file_path = 'new_words.txt'

with open(source_file_path, 'r') as source_file, open(target_file_path, 'w') as target_file:
    file_copy(source_file, target_file)

print(f"Copying '{source_file_path}' to '{target_file_path}'")

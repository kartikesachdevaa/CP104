"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Kartike Sachdeva
ID:      169049497
Email:   sach9497@mylaurier.ca
__updated__ = "2023-11-23"
-------------------------------------------------------
"""
# Imports
from functions import number_stats
# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


fh = 'numbers.txt'

with open(fh, 'r') as file_handle:
    smallest, largest, total, average = number_stats(file_handle)


print(f"Smallest: {smallest}")
print(f"Largest: {largest}")
print(f"Total: {total:.2f}")
print(f"Average: {average:.2f}")

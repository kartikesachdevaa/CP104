"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Kartike Sachdeva
ID:      169049497
Email:   sach9497@mylaurier.ca
__updated__ = "2023-10-28"
-------------------------------------------------------
"""
# Imports
from functions import colour_combine
# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


rgb_colour1 = input("Enter the first primary RGB color: ").lower()
rgb_colour2 = input("Enter the second primary RGB color: ").lower()

result = colour_combine(rgb_colour1, rgb_colour2)
print(f'colour_combine("{rgb_colour1}", "{rgb_colour2}") -> {result}')

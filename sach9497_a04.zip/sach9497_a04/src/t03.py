"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Kartike Sachdeva
ID:      169049497
Email:   sach9497@mylaurier.ca
__updated__ = "2023-10-28"
-------------------------------------------------------
"""
# Imports
from functions import largest_average
# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


val1 = float(input("Enter the first value (val1): "))
val2 = float(input("Enter the second value (val2): "))
val3 = float(input("Enter the third value (val3): "))

result = largest_average(val1, val2, val3)
print(f"largest_average({val1}, {val2}, {val3}) -> {result}")
